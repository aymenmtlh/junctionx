import React from "react";
import "./Components.css";
import { usePondContext } from "../PondContext";

export default function Alert({Ph,Oxy,Temp,Case}) {
    const { pondData } = usePondContext();
  return (
    <div className="alert-box">
      <h4 className="alert-title">❗ This Pond ID:{pondData.id} is in danger.</h4>
      <p className="alert-message">
        You need to take action immediately.<br />
        ⚠️ <strong>{Ph} {Oxy}  {Temp}   level is {Case}</strong>
      </p>
    </div>
  );
}