import React, { useEffect, useState } from "react";
import axios from "axios";
import { CloudCog } from "lucide-react";

const score = (value, optimal, acceptable) => {
  if (value >= optimal[0] && value <= optimal[1]) return 100;
  if (value >= acceptable[0] && value <= acceptable[1]) {
    const dist = Math.min(Math.abs(value - optimal[0]), Math.abs(value - optimal[1]));
    const maxDist = Math.max(
      Math.abs(optimal[0] - acceptable[0]),
      Math.abs(optimal[1] - acceptable[1])
    );
    return Math.max(60, 100 - (dist / maxDist) * 40);
  }
  return 0;
};

const Result = ({ pondId }) => {
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  console.log(health)
  

  const weights = {
    temperature: 0.15,
    pH: 0.15,
    oxygen: 0.15,
    ammonia: 0.15,
    water_level: 0.10,
    split_level: 0.10,
    nitrite: 0.10,
    nitrate: 0.10,
  };

  const ranges = {
    temperature: { optimal: [24, 28], acceptable: [20, 32] },
    pH: { optimal: [6.5, 8.5], acceptable: [6.0, 9.0] },
    oxygen: { optimal: [5, 8], acceptable: [3, 10] },
    ammonia: { optimal: [0, 0.5], acceptable: [0, 1.0] },
    split_level: { optimal: [0, 5], acceptable: [0, 8] },
    nitrite: { optimal: [0, 0.2], acceptable: [0, 0.5] },
    nitrate: { optimal: [0, 40], acceptable: [0, 80] },
  };

  useEffect(() => {
    const fetchHealth = async () => {
      try {
        const res = await axios.get(`http://localhost:3000/api/measurements/pond/${pondId}`);
        const latest = res.data[0];
        console.log(pondId)

        if (!latest) {
          setHealth(null);
          setLoading(false);
          return;
        }

        const total =
          score(latest.temperature, ranges.temperature.optimal, ranges.temperature.acceptable) * weights.temperature +
          score(latest.ph, ranges.pH.optimal, ranges.pH.acceptable) * weights.pH +
          score(latest.dissolved_oxygen, ranges.oxygen.optimal, ranges.oxygen.acceptable) * weights.oxygen +
          score(latest.ammonia, ranges.ammonia.optimal, ranges.ammonia.acceptable) * weights.ammonia +
          (latest.water_level === "Normal" ? 100 : 50) * weights.water_level +
          score(latest.split_level, ranges.split_level.optimal, ranges.split_level.acceptable) * weights.split_level +
          score(latest.nitrite, ranges.nitrite.optimal, ranges.nitrite.acceptable) * weights.nitrite +
          score(latest.nitrate, ranges.nitrate.optimal, ranges.nitrate.acceptable) * weights.nitrate;

        setHealth(Math.round(total));
      } catch (err) {
        console.error("❌ Failed to fetch measurements:", err);
        setHealth(null);
      } finally {
        setLoading(false);
      }
    };

    fetchHealth();
  }, [pondId]);

  if (loading) return <p>Loading...</p>;

  return (
    <div style={{ padding: "1rem", border: "1px solid #ccc", borderRadius: "8px" }}>
      <h3>Estimated Pond Health</h3>
      {health !== null ? (
        <p
          style={{
            fontSize: "100px",
            fontWeight: "bold",
            color: health >= 70 ? "green" : health >= 50 ? "orange" : "red",
          }}
        >
          {health}%
        </p>
      ) : (
        <p style={{ color: "gray" }}>No data available</p>
      )}
    </div>
  );
};

export default Result;