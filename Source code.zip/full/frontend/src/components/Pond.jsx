import "./Components.css";
import { usePondContext } from "../PondContext";
import Alert from "./Alert";
import Simulator from "./Simulator";
import DataPanel from "./DataPanel";
import ChartComponent from "./ChartComponent";
import FakeChart from "./FakeChart";

import Strem from "./Strem";

export default function Pond({ onBack }) {
  const { pondData, loading } = usePondContext();



  if (loading) return <p>Loading...</p>;
  if (!pondData) return <p>No data available.</p>;

  // 🧠 استخراج القيم من metrics
  const getMetricValue = (label) => {
    const metric = pondData.metrics?.find((m) => m.label === label);
    return metric?.value ?? null;
  };

  const temperature = getMetricValue("Temperature");
  const ph = getMetricValue("pH");
  const oxygen = getMetricValue("Oxygen");
  const name = getMetricValue("name");

  let alertComponent = null;

  if (temperature !== null) {
    if (temperature < 20) {
      alertComponent = <Alert Temp="Temperature" Case="Low" />;
      
    } else if (temperature > 32) {
      alertComponent = <Alert Temp="Temperature" Case="High" />;
       
    }
  }

  if (!alertComponent && ph !== null) {
    if (ph < 6) {
      alertComponent = <Alert Ph="Ph" Case="Low" />;
    
    } else if (ph > 9) {
      alertComponent = <Alert Ph="Ph" Case="High" />;
       
    }
  }

  if (!alertComponent && oxygen !== null) {
    if (oxygen < 3) {
      alertComponent = <Alert Oxy="Oxygen" Case="Low" />;
      
    } else if (oxygen > 10) {
      alertComponent = <Alert Oxy="Oxygen" Case="High" />;
       
    }
  }

  return (
    <div className="pond-container">
      <button
        onClick={onBack}
        style={{
          padding: "0.5rem 1rem",
          background: "#222",
          color: "#fff",
          border: "none",
          borderRadius: "8px",
          cursor: "pointer",
          marginBottom: "1rem",
        }}
      >
        ← Back
      </button>

      {alertComponent}

      <div className="main-content">
        <div className="pond-header">
          <h1 className="pond-title">{pondData.name}</h1>
          <p className="pond-id">ID: {pondData.id}</p>
        </div>

        <div className="main-grid">
          <Simulator />
          <DataPanel />
        </div>

        <div className="mainChart">
          <Strem />
          <ChartComponent />
        </div>
      </div>
    </div>
  );
}
