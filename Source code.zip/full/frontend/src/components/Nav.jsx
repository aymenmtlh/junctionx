// import { Link } from "react-router-dom";
// import "../App.css";

// export default function Nav() {
//   return (
//     <nav
//       style={{
//         display: "flex",
//         gap: "1rem",
//         padding: "1rem",
//         background: "#222",
//         color: "#fff",
//       }}
//     >
//       <Link to="/" style={{ color: "white" }}>
//         Home
//       </Link>
//       <Link to="/about" style={{ color: "white" }}>
//         About
//       </Link>
//       <Link to="/contact" style={{ color: "white" }}>
//         Contact
//       </Link>
//     </nav>
//   );
// }
