// ChartComponent.jsx
import { useState } from "react";
import "./Components.css";
import { ChevronDown } from "lucide-react";

// بيانات تجريبية
const sampleData = {
  Daily: {
    Ph: [6.8, 7.0, 7.2, 7.1, 6.9, 7.3, 7.0],
    Temperature: [22, 23, 24, 24.5, 25, 24, 23.5],
    Oxygen: [6.5, 6.7, 6.8, 6.6, 6.9, 7.0, 6.8],
  },
  Weekly: {
    Ph: [7.1, 7.0, 7.2, 7.3, 7.1, 7.0, 7.2],
    Temperature: [23, 24, 25, 24.5, 24, 23.5, 24],
    Oxygen: [6.8, 6.7, 6.9, 7.0, 6.9, 6.8, 7.1],
  },
  Monthly: {
    Ph: [6.9, 7.0, 7.2, 7.3, 7.1, 7.0, 7.2],
    Temperature: [22, 23.5, 24, 24.5, 24, 23.5, 24],
    Oxygen: [6.5, 6.6, 6.8, 6.9, 6.7, 6.8, 6.9],
  },
};

export default function ChartComponent() {
  const [metric, setMetric] = useState("Ph");
  const [period, setPeriod] = useState("Daily");

  const dataPoints = sampleData[period][metric];
  const maxValue = Math.max(...dataPoints);
  const minValue = Math.min(...dataPoints);

  const svgWidth = 800;
  const svgHeight = 200;
  const graphHeight = 160;
  const paddingBottom = 20;

  const getX = (index) => (index * svgWidth) / (dataPoints.length - 1);
  const getY = (value) =>
    svgHeight - paddingBottom - ((value - minValue) / (maxValue - minValue)) * graphHeight;

  return (
    <div className="chart-container">
      <div className="chart-header">
        <div className="chart-dropdown">
          <select style={{color:"black",background:"white"}} value={metric} onChange={(e) => setMetric(e.target.value)}>
            <option value="Ph">Ph</option>
            <option value="Temperature">Temperature</option>
            <option value="Oxygen">Oxygen</option>
          </select>
          <ChevronDown className="chart-dropdown-icon" />
        </div>

        <div className="chart-dropdown">
          <select  style={{color:"black",background:"white"}} value={period} onChange={(e) => setPeriod(e.target.value)}>
            <option value="Daily">Daily</option>
            <option value="Weekly">Weekly</option>
            <option value="Monthly">Monthly</option>
          </select>
          <ChevronDown className="chart-dropdown-icon" />
        </div>
      </div>

      <div className="chart-svg-container">
        <svg className="chart-svg" viewBox={`0 0 ${svgWidth} ${svgHeight}`}>
          {/* الخط */}
          <path
            d={`M ${dataPoints
              .map((val, i) => `${getX(i)},${getY(val)}`)
              .join(" L ")}`}
            className="chart-line"
          />

          {/* تعبئة */}
          <path
            d={`M ${dataPoints
              .map((val, i) => `${getX(i)},${getY(val)}`)
              .join(" L ")} L ${svgWidth},${svgHeight} L 0,${svgHeight} Z`}
            fill="url(#gradient)"
            opacity="0.3"
          />

          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#3B82F6" stopOpacity="0.1" />
            </linearGradient>
          </defs>

          {/* النقاط */}
          {dataPoints.map((val, i) => (
            <circle
              key={i}
              cx={getX(i)}
              cy={getY(val)}
              r="6"
              className="chart-point"
            />
          ))}
        </svg>
      </div>

      <div className="chart-labels">
        {dataPoints.map((_, index) => (
          <span key={index} className="chart-label">
            {`Point ${index + 1}`}
          </span>
        ))}
      </div>
    </div>
  );
}
