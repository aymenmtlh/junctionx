import { usePondContext } from "../PondContext";
import "./Components.css";

export default function Stream({ title, mainText }) {
  const { pondData } = usePondContext();
  console.log(pondData.health.percentage);

  return (
    <div className="Strem-container">
      <h2 className="Strem-title">{title}</h2>

      {/* Titre spécifique للفيديو */}
      <h3 className="Strem-subtitle">Live Detection</h3>

      <div className="Strem-placeholder">
        <video width="500px" style={{ objectFit: "cover" }} autoPlay loop muted>
          <source src="/detection.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
    </div>
  );
}
