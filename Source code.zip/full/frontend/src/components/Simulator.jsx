import { usePondContext } from "../PondContext";
import "./Components.css";

export default function Simulator() {
  const { pondData } = usePondContext();

  const simuImg = () => {
    const levelMetric = pondData?.metrics?.find(m => m.label === "Water level");
    const level = levelMetric?.value;

    if (level >= 0 && level <= 2.5) {
      return "/low.png";
    } else if (level > 2.5 && level < 3.5) {
      return "/meduim.png";
    } else if (level >= 3.5 && level <= 5) {
      return "/norm.png";
    } else {
      return "/unknown.png"; // أو null إذا لم تكن هناك صورة
    }
  };

  return (
    <div className="simulator-container">
      <h2 className="simulator-title">Simulation 3D du niveau d’eau</h2>

      <div className="simulator-placeholder">
        <img
          src={simuImg()}
          alt="Health level"
          className="sim"
          style={{ minWidth: "300px" }}
        />
      </div>
    </div>
  );
}
