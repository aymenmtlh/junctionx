import { usePondContext } from "../PondContext";
import "./Components.css";
import Result from "./Result";

function getHealthClass(percentage) {
  if (percentage >= 80) return "health-good";
  if (percentage >= 50) return "health-average";
  return "health-poor";
}

function getHealthStatusClass(status) {
  switch (status) {
    case "Good":
      return "status-good";
    case "Average":
      return "status-average";
    case "Poor":
      return "status-poor";
    default:
      return "";
  }
}

export default function DataPanel() {
  const { pondData } = usePondContext();

  // Handle loading or null context
  if (!pondData || !pondData.metrics || !pondData.health) {
    return <div className="pond-data-container">No pond data available.</div>;
  }

  const { metrics, health } = pondData;

  return (
    <div className="pond-data-container">
      <div className="pond-data-grid">
        {/* Metrics */}
        <div className="metrics-container">
          <div className="metrics-list">
            {metrics.map((metric, index) => (
              <div key={index} className="metric-item">
                <span className="metric-label">{metric.label} :</span>
                <span className="metric-value">
                  {metric.value} {metric.unit}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Health Estimate */}
       <Result pondId={pondData.id} />
      </div>
    </div>
  );
}
