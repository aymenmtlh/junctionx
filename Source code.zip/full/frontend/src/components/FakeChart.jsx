import { useState } from "react";
import "./Components.css";

const fakeData = {
  Temperature: Array.from({ length: 7 }, (_, i) => ({
    day: `Day ${i + 1}`,
    value: Math.random() * 10 + 20,
  })),
  pH: Array.from({ length: 7 }, (_, i) => ({
    day: `Day ${i + 1}`,
    value: Math.random() * 2 + 6,
  })),
  Oxygen: Array.from({ length: 7 }, (_, i) => ({
    day: `Day ${i + 1}`,
    value: Math.random() * 5 + 4,
  })),
  Ammonia: Array.from({ length: 7 }, (_, i) => ({
    day: `Day ${i + 1}`,
    value: Math.random() * 1.2,
  })),
};

export default function FakeChart() {
  const [selectedMetric, setSelectedMetric] = useState("Temperature");
  const data = fakeData[selectedMetric];
  const maxValue = Math.max(...data.map((d) => d.value));

  return (
    <div className="chart-container">
      <div className="chart-header">
        <select
          className="chart-dropdown"
          value={selectedMetric}
          onChange={(e) => setSelectedMetric(e.target.value)}
        >
          {Object.keys(fakeData).map((metric) => (
            <option key={metric} value={metric}>
              {metric}
            </option>
          ))}
        </select>
      </div>

      <svg className="chart-svg" viewBox="0 0 800 200">
        {/* خط البيانات */}
        <path
          d={`M ${data
            .map((point, i) => {
              const x = (i * 800) / (data.length - 1);
              const y = 200 - (point.value / maxValue) * 160;
              return `${x},${y}`;
            })
            .join(" L ")}`}
          className="chart-line"
          fill="none"
          stroke="#3B82F6"
          strokeWidth="3"
        />

        {/* النقاط */}
        {data.map((point, i) => {
          const cx = (i * 800) / (data.length - 1);
          const cy = 200 - (point.value / maxValue) * 160;
          return <circle key={i} cx={cx} cy={cy} r="6" fill="#3B82F6" />;
        })}

        {/* الأيام */}
        {data.map((point, i) => {
          const x = (i * 800) / (data.length - 1);
          return (
            <text key={i} x={x} y={195} fontSize="12" textAnchor="middle">
              {point.day}
            </text>
          );
        })}
      </svg>
    </div>
  );
}
