import {
  BrowserRouter as Router,
  Routes,
  Route,
  NavLink,
} from "react-router-dom";
import { useState } from "react";

import MyPonds from "./pages/MyPonds";
import Users from "./pages/Users";
import Notifications from "./pages/Notifications";
import { PondProvider } from "./PondContext";
import { NotificationProvider } from "./NotificationContext";
import { Toaster } from "sonner";

import "./App.css"

    

function App() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    
  <NotificationProvider> <PondProvider>
      <Router>
              <Toaster richColors position="top-right" />

        <div
          style={{
            display: "flex",
            fontFamily: "Plus Jakarta Sans",
            gap: "0",
            padding: "0",
            height: "100vh",
          }}
        >
          <nav
        
            style={{
              maxWidth: collapsed ? "80px" : "200px",
              width: collapsed ? "80px" : "200px",
              height: "100vh",
              background: "#222",
              color: "#fff",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: "30px",
              padding: "2rem 1rem",
              fontFamily: "Plus Jakarta Sans",
              cursor: "pointer",
              transition: "width 0.3s ease",
              boxSizing: "border-box",
            }}
          >
            <img src="/Ellipse 1.png" alt="Logo" className="shadow" />
            <img      onClick={() => setCollapsed(!collapsed)} src="/Group 3.png" alt="Logo text" className="navbar" />

            <SidebarLink
              to="/"
              text="My Ponds"
              icon="/Home icon.png"
              collapsed={collapsed}
            />
            <SidebarLink
              to="/notifications"
              text="Notifications"
              icon="/si_notifications-alt-line.png"
              collapsed={collapsed}
            />
            <SidebarLink
              to="/users"
              text="Users"
              icon="/solar_user-linear.png"
              collapsed={collapsed}
            />
            <SidebarLink
              to="https://cdn.botpress.cloud/webchat/v3.2/shareable.html?configUrl=https://files.bpcontent.cloud/2025/07/18/23/20250718232501-KL0R3FBK.json"
              text="Ai Advisor"
              icon="/ix_ai.png"
              collapsed={collapsed}
            />
          </nav>

          <div
            style={{
              flex: 1,
              padding: "0",
              fontFamily: "Plus Jakarta Sans",
              height: "100vh",
              overflowY: "auto",
              boxSizing: "border-box",
            }}
          >
            <header>
              <div className="first">
                <h1 style={{fontSize:"30px"}}>Welcome To our Website</h1>
              </div>
              <div className="imgs">
                <img src="/image 1.png" />
                <img src="/Rectangle 37.png" />
              </div>
            </header>
            <Routes>
              <Route path="/" element={<MyPonds />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/users" element={<Users />} />
           
            </Routes>
          </div>
        </div>
      </Router>
    </PondProvider></NotificationProvider>
   
  );
}

// ✅ SidebarLink component
function SidebarLink({ to, text, icon, collapsed }) {
  return (
    <NavLink
      to={to}
      end
      style={({ isActive }) => ({
        color: isActive ? "#f00" : "#fff",
        marginBottom: "1rem",
        display: "flex",
        alignItems: "center",
        gap: "10px",
        textDecoration: "none",
        width: "100%",
        justifyContent: collapsed ? "center" : "flex-start",
        fontFamily: "Plus Jakarta Sans",
        transition: "all 0.2s ease",
        paddingLeft: collapsed ? "0" : "10px",
      })}
    >
      <img
        src={icon}
        alt={text}
        style={{
          width: "24px",
          height: "24px",
        }}
      />
      {!collapsed && <p>{text}</p>}
    </NavLink>
  );
}

export default App;
