import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import "../components/Users.css";

import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { Password } from "primereact/password";
import { Toast } from "primereact/toast";

import "primereact/resources/themes/lara-light-blue/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";

const Users = () => {
  const toast = useRef(null);
  const [users, setUsers] = useState([]);
  const [showForm, setShowForm] = useState(false);

  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    password: "",
    pond_from: "",
    pond_to: "",
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await axios.get("http://localhost:3000/api/users");
      setUsers(res.data);
    } catch (err) {
      console.error("❌ Failed to load users:", err);
    }
  };

  const handleInputChange = (id, field, value) => {
    setUsers((prev) =>
      prev.map((user) => (user.user_id === id ? { ...user, [field]: value } : user))
    );
  };

  const handleAccept = async (id) => {
    const user = users.find((u) => u.user_id === id);
    try {
      await axios.put(`http://localhost:3000/api/users/${id}`, {
        pond_from: user.pond_from || null,
        pond_to: user.pond_to || null,
      });
      toast.current.show({ severity: "success", summary: "Updated", detail: "Pond assigned" });
    } catch (err) {
      toast.current.show({ severity: "error", summary: "Error", detail: "Assign failed" });
    }
  };

  const handleRefuse = (id) => {
    setUsers((prev) =>
      prev.map((user) =>
        user.user_id === id ? { ...user, pond_from: "", pond_to: "" } : user
      )
    );
  };

  const handleDeleteUser = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/api/users/${id}`);
      toast.current.show({ severity: "success", summary: "Deleted", detail: "User removed" });
      setUsers((prev) => prev.filter((user) => user.user_id !== id));
    } catch (err) {
      toast.current.show({ severity: "error", summary: "Error", detail: "Failed to delete user" });
    }
  };

  const handleAddUser = async () => {
    const { name, email, password, pond_from, pond_to } = newUser;
    if (!name || !email || !password) {
      toast.current.show({ severity: "warn", summary: "Required", detail: "Please fill all fields" });
      return;
    }

    try {
      await axios.post("http://localhost:3000/api/users", {
        name,
        email,
        password,
        role: "observer",
        pond_from: pond_from || null,
        pond_to: pond_to || null,
      });
      setNewUser({
        name: "",
        email: "",
        password: "",
        pond_from: "",
        pond_to: "",
      });
      setShowForm(false);
      fetchUsers();
      toast.current.show({ severity: "success", summary: "Success", detail: "User added" });
    } catch (err) {
      toast.current.show({ severity: "error", summary: "Failed", detail: "User creation failed" });
    }
  };

  return (
    <div className="users-container relative">
      <Toast ref={toast}  />

      
      

      {/* Add User Button */}
      <Button
        icon="pi pi-user-plus"
        label="Add User"
        className=" mb-3"
        onClick={() => setShowForm(true)}
        style={{borderRadius:"10px",padding:"10px",background:"black", border:"none" , position:"absolute",top:"-50px",left:"0px" , display:"flex",alignItems:"center",gap:"10px"}}
      />

      {/* Dialog Form */}
      <Dialog
        header="Add New User"
        visible={showForm}
        style={{ width: "30vw", padding:"30px" }}
        onHide={() => setShowForm(false)}
        modal
      >
        <div className="p-fluid"  style={{ padding:"20px" ,display:"flex",flexDirection:"column",gap:"10px", }}>
          <label>Name</label>
          <InputText
            value={newUser.name}onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
          />
          <label className="mt-2">Email</label>
          <InputText
            type="email"
            value={newUser.email}
            onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
          />
          <label className="mt-2">Password</label>
          <Password
            value={newUser.password}
            onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
            toggleMask
            feedback={false}
          />
          <label className="mt-2">Pond From</label>
          <InputText
            type="number"
            value={newUser.pond_from}
            onChange={(e) => setNewUser({ ...newUser, pond_from: e.target.value })}
          />
          <label className="mt-2">Pond To</label>
          <InputText
            type="number"
            value={newUser.pond_to}
            onChange={(e) => setNewUser({ ...newUser, pond_to: e.target.value })}
          />
          <Button
            label="Save"
            icon="pi pi-check"
            className="p-button-success mt-3"
            onClick={handleAddUser}
          />
        </div>
      </Dialog>

      {/* Table */}
      <table className="users-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Pond Assignment</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map(({ user_id, name, email, pond_from, pond_to }) => (
            <tr key={user_id}>
              <td>{name}</td>
              <td>{email}</td>
              <td>
                <p>from {pond_from} to {pond_to} ponds</p>
              </td>
              <td className="actions">
                <Button
                  icon="pi pi-trash"
                  className="p-button-danger p-button-rounded p-button-sm"
                  onClick={() => handleDeleteUser(user_id)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Users;