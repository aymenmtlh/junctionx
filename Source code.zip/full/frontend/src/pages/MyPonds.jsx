import React, { useState, useEffect } from "react";
import Pond from "../components/Pond";
import { usePondContext } from "../PondContext";
import axios from "axios";
import "../App.css";

const MyPonds = () => {
  const [selectedPond, setSelectedPond] = useState(null);
  const [pondList, setPondList] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const { setPondId } = usePondContext();

  useEffect(() => {
    const fetchPonds = async () => {
      try {
        const res = await axios.get("http://localhost:3000/api/ponds");
        const ponds = res.data;

        const pondsWithWater = await Promise.all(
          ponds.map(async (pond) => {
            try {
              const measRes = await axios.get(
                `http://localhost:3000/api/measurements/pond/${pond.pond_id}`
              );
              const last = measRes.data[0];
              return {
                ...pond,
                water_level: last?.water_level ?? "N/A",
              };
            } catch {
              return { ...pond, water_level: "N/A" };
            }
          })
        );

        setPondList(pondsWithWater);
      } catch (err) {
        console.error("Error loading ponds:", err);
      }
    };

    fetchPonds();
  }, []);

  const handleSelect = (pond) => {
    setPondId(pond.pond_id);
    setSelectedPond(pond.pond_id);
  };

  const getStatusText = (level) => {
    const value = parseFloat(level);
    if (isNaN(value)) {
      return <span style={{ color: "gray" }}>Water level unknown</span>;
    } else if (value >= 0 && value <= 2.5) {
      return <span style={{ color: "orange" }}>Water level is low</span>;
    } else if (value > 2.5 && value < 3.5) {
      return <span style={{ color: "gold" }}>Water level is medium</span>;
    } else if (value >= 3.5 && value <= 5) {
      return <span style={{ color: "green" }}>Water level is normal</span>;
    } else {
      return <span style={{ color: "gray" }}>Water level unknown</span>;
    }
  };

  const filteredPonds = pondList.filter((pond) =>
    pond.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pond.pond_id.toString().includes(searchTerm)
  );

  if (selectedPond !== null) {
    return <Pond onBack={() => setSelectedPond(null)} />;
  }

  return (
    <div className="a">
      <div className="mainInput">
        <input
          type="text"
          placeholder="Search Pond by ID or Name"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <img src="/mynaui_grid-solid.png" alt="" />
      </div>
      <section className="main">
        {filteredPonds.length > 0 ? (
          filteredPonds.map((pond) => (
            <div
              key={pond.pond_id}
              className="pond"
              style={{ cursor: "pointer" , paddingBottom:"40px"}}
              onClick={() => handleSelect(pond)}
            >
              <div className="headerPoid">
                <p>{pond.name}</p>
                <span>{getStatusText(pond.water_level)}</span>
              </div>
              <div className="dataPoid">
                <p>ID: {pond.pond_id}</p>
                <p>Water level: {pond.water_level}</p>
              </div>
              <img src="/famicons_water.png" alt="" className="katra" />
            </div>
          ))
        ) : (
          <p style={{ textAlign: "center", marginTop: "2rem" }}>
            No ponds found.
          </p>
        )}
      </section>
    </div>
  );
};

export default MyPonds;
