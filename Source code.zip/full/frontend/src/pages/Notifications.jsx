import React from "react";
import "../components/Components.css";


export default function Notifications() {
   
  return ( 
    <div>
          <div className="alert-box">
      <h4 className="alert-title">❗ This Pond ID:1 is in danger.</h4>
      <p className="alert-message">
        You need to take action immediately.<br />
        ⚠️ <strong>Ph   level is LOW</strong>
      </p>
    </div>
    <div className="alert-box">
      <h4 className="alert-title">❗ This Pond ID:2 is in danger.</h4>
      <p className="alert-message">
        You need to take action immediately.<br />
        ⚠️ <strong>Temp   level is HIGH</strong>
      </p>
    </div>
    <div className="alert-box">
      <h4 className="alert-title">❗ This Pond ID:3 is in danger.</h4>
      <p className="alert-message">
        You need to take action immediately.<br />
        ⚠️ <strong>Oxygen   level is HIGH</strong>
      </p>
    </div>
    <div className="alert-box">
      <h4 className="alert-title">❗ This Pond ID:4 is in danger.</h4>
      <p className="alert-message">
        You need to take action immediately.<br />
        ⚠️ <strong>Ph   level is LOW</strong>
      </p>
    </div>
    </div>
  )
}