import React, { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";
import { toast } from "sonner";

const PondContext = createContext();

export const PondProvider = ({ children }) => {
  const [pondId, setPondId] = useState(null);
  const [pondData, setPondData] = useState(null);
  const [loading, setLoading] = useState(false);

  const updateChartSettings = (settings) => {
    setPondData((prev) => ({
      ...prev,
      chartSettings: {
        ...prev.chartSettings,
        ...settings,
      },
    }));
  };

  const calculateHealth = (latest) => {
    const rules = {
      temperature: { optimal: [20, 28], weight: 0.25 },
      ph: { optimal: [6.5, 8.5], weight: 0.25 },
      dissolved_oxygen: { optimal: [5, 10], weight: 0.25 },
      ammonia: { optimal: [0, 0.5], weight: 0.25 }
    };

    let total = 0;
    let failed = 0;

    for (const key in rules) {
      const val = parseFloat(latest[key]);
      const { optimal, weight } = rules[key];

      if (val >= optimal[0] && val <= optimal[1]) {
        total += 100 * weight;
      } else {
        let score = 0;
        if (val < optimal[0]) {
          const dist = optimal[0] - val;
          score = Math.max(60, 100 - (dist / optimal[0]) * 40);
        } else {
          const dist = val - optimal[1];
          score = Math.max(60, 100 - (dist / optimal[1]) * 40);
        }
        total += score * weight;
        if (score === 0) failed++;
      }
    }

    // تخفيض حسب عدد المؤشرات الخطيرة
    if (failed > 0) {
      total *= Math.pow(0.7, failed);
    }

    return Math.round(total);
  };

  useEffect(() => {
    const fetchData = async () => {
      if (!pondId) return;
      setLoading(true);

      try {
        // 🐟 بيانات الحوض
const pondRes = await axios.get(`http://localhost:3000/api/ponds/${pondId}`);
        const pond = pondRes.data;

        // 📊 القياسات
        const measRes = await axios.get(`http://localhost:3000/api/measurements/pond/${pondId}`);
        const measurements = measRes.data;
        const latest = measurements[0];

        // ⚙️ المقاييس الحالية
        const metrics = [
          { label: "Temperature", value: latest?.temperature ?? 0, unit: "°C" },
          { label: "pH", value: latest?.ph ?? 0, unit: "" },
          { label: "Oxygen", value: latest?.dissolved_oxygen ?? 0, unit: "L/min" },
          { label: "Ammonia", value: latest?.ammonia ?? 0, unit: "mol/L" },
          { label: "Water level", value: latest?.water_level ?? 0, unit: "m" },
          { label: "Sality level", value: latest?.salinity ?? 0, unit: "g/L" },
          { label: "Nitrite Level", value: latest?.nitrite ?? 0, unit: "mg/L" },
          { label: "Nitrate Leve", value: latest?.nitrate ?? 0, unit: "mg/L" },
        ];

        // 📈 بيانات الرسم البياني
       const chartData = {
  Temperature: measurements.map((m, i) => ({ day: `Day ${i + 1}`, value: m.temperature })),
  pH: measurements.map((m, i) => ({ day: `Day ${i + 1}`, value: m.ph })),
  Oxygen: measurements.map((m, i) => ({ day: `Day ${i + 1}`, value: m.dissolved_oxygen })),
  Ammonia: measurements.map((m, i) => ({ day: `Day ${i + 1}`, value: m.ammonia })),
};

        // 🧠 حساب الصحة
        const healthPercentage = calculateHealth(latest);
        const healthStatus = healthPercentage >= 70 ? "Good" : "Bad";

        // 🚨 تنبيه فوري إذا كانت الصحة منخفضة
        if (healthPercentage <= 50) {
        toast.error(`Pond ${pond.name} is in danger!`, {
  description: `Health: ${healthPercentage}% — click to view.`,
  onClick: () => (window.location.href = `/pond/${pond.pond_id}`),
  duration: 6000,
});
        }

        // 🧩 تخزين البيانات
        setPondData({
          id: pond.pond_id,
          name: pond.name,
          metrics,
          chartData,
          chartSettings: {
            selectedMetric: "Temperature",
            selectedPeriod: "Weekly",
            availableMetrics: ["Temperature", "pH", "Oxygen", "Ammonia"],
            availablePeriods: ["Daily", "Weekly", "Monthly"],
          },
          health: {
            percentage: healthPercentage,
            status: healthStatus,
          },
        });

      } catch (error) {
        console.error("❌ Error loading pond data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [pondId]);

  return (
    <PondContext.Provider
      value={{ pondId, setPondId, pondData, updateChartSettings, loading }}
    >
      {children}
    </PondContext.Provider>
  );
};

export const usePondContext = () => useContext(PondContext);