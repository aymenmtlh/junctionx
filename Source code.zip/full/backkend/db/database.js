const mysql = require('mysql2/promise');

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "Elhou1234@",
  database: "controle",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Tester la connexion
(async () => {
  try {
    const connection = await db.getConnection();
    console.log("✅ Connexion à MySQL réussie !");
    connection.release(); // Très important de libérer la connexion
  } catch (err) {
    console.error("❌ Erreur de connexion à MySQL :", err.message);
  }
})();

module.exports = db;
