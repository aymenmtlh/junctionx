const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// ✅ تفعيل CORS للسماح للواجهة (React) بالتواصل مع الخادم
app.use(cors());

// ✅ تحليل البيانات القادمة من الواجهة (JSON)
app.use(express.json());

// ✅ استيراد الراوترات
const pondRoutes = require('./routes/pondRoutes');
const measurementRoutes = require('./routes/measurementRoutes');
const alertRoutes = require('./routes/alertRouters');
const userRoutes = require("./routes/userRoutes");
const swaggerUi = require("swagger-ui-express");
const swaggerSpec = require("./swaggerConfig");

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
// ✅ تحديد المسارات
app.use('/api/ponds', pondRoutes);
app.use('/api/measurements', measurementRoutes);
app.use('/api/alerts', alertRoutes);
app.use("/api/users", userRoutes);
// ✅ تشغيل الخادم
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
console.log(`✅ Server running on port ${PORT}`);
});