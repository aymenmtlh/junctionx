const db = require("../db/database"); // تأكد أنه mysql2 pool

// Get all users
exports.getAllUsers = async () => {
  const [rows] = await db.query("SELECT * FROM users");
  return rows;
};

// Get user by ID
exports.getUserById = async (id) => {
  const [rows] = await db.query("SELECT * FROM users WHERE user_id = ?", [id]);
  return rows[0];
};

// Create new user
exports.createUser = async ({ name, email, password, role }) => {
  const [result] = await db.query(`
    INSERT INTO users (name, email, password_hash, role)
     VALUES (?, ?, ?, ?)`,
    [name, email, password, role || 'observer']
  );

  const insertedId = result.insertId;

  const [rows] = await db.query("SELECT * FROM users WHERE user_id = ?", [insertedId]);
  return rows[0];
};
exports.deleteUser = async (id) => {
  // أولاً نحرر الحقول المرتبطة
  await db.query("UPDATE ponds SET user_id = NULL WHERE user_id = ?", [id]);

  // ثم نحذف المستخدم
  const [result] = await db.query("DELETE FROM users WHERE user_id = ?", [id]);
  return result;
};