const db = require('../db/database');

exports.getAllMeasurements = async () => {
  const [rows] = await db.query('SELECT * FROM measurements');
  return rows;
};

exports.getMeasurementById = async (id) => {
  const [rows] = await db.query('SELECT * FROM measurements WHERE measurement_id = ?', [id]);
  return rows[0];
};

exports.getMeasurementsByPondId = async (pond_id) => {
  const [rows] = await db.query('SELECT * FROM measurements WHERE pond_id = ?', [pond_id]);
  return rows;
};

exports.createMeasurement = async (data) => {
  const {
    pond_id, timestamp, nitrite, nitrate, ammonia,
    ph, temperature, dissolved_oxygen, salinity, water_level
  } = data;

  const [result] = await db.query(
  `INSERT INTO measurements (
    pond_id, timestamp, nitrite, nitrate, ammonia,
    ph, temperature, dissolved_oxygen, salinity, water_level
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  [pond_id, timestamp, nitrite, nitrate, ammonia, ph, temperature, dissolved_oxygen, salinity, water_level]
);


  return { id: result.insertId, ...data };
};

exports.deleteMeasurement = async (id) => {
  const [result] = await db.query('DELETE FROM measurements WHERE measurement_id = ?', [id]);
  return result.affectedRows > 0;
};