const db = require('../db/database');

exports.getAllAlerts = async () => {
  const [rows] = await db.query('SELECT * FROM alerts');
  return rows;
};

exports.getAlertById = async (id) => {
  const [rows] = await db.query('SELECT * FROM alerts WHERE alert_id = ?', [id]);
  return rows[0];
};

exports.getAlertsByPondId = async (pond_id) => {
  const [rows] = await db.query('SELECT * FROM alerts WHERE pond_id = ?', [pond_id]);
  return rows;
};

exports.createAlert = async (data) => {
  const { pond_id, measurement_id, alert_type, message, severity } = data;

  const [result] = await db.query(
    'INSERT INTO alerts (pond_id, measurement_id, alert_type, message, severity) VALUES (?, ?, ?, ?, ?)',
    [pond_id, measurement_id, alert_type, message, severity]
  );

  return { id: result.insertId, ...data };
};

exports.deleteAlert = async (id) => {
  const [result] = await db.query('DELETE FROM alerts WHERE alert_id = ?', [id]);
  return result.affectedRows > 0;
};