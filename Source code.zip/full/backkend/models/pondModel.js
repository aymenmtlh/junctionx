const db = require('../db/database');

exports.getAllPonds = async () => {
  const [rows] = await db.query('SELECT * FROM ponds');
  return rows;
};

exports.getPondById = async (id) => {
  const [rows] = await db.query('SELECT * FROM ponds WHERE pond_id = ?', [id]);
  return rows[0];
};

exports.createPond = async (name, location, user_id) => {
  const [result] = await db.query(
    'INSERT INTO ponds (name, location, user_id) VALUES (?, ?, ?)',
    [name, location, user_id]
  );
  return { id: result.insertId, name, location, user_id };
};

exports.updatePond = async (id, name, location) => {
  const [result] = await db.query(
    'UPDATE ponds SET name = ?, location = ? WHERE pond_id = ?',
    [name, location, id]
  );
  return result.affectedRows > 0;
};

exports.deletePond = async (id) => {
  const [result] = await db.query('DELETE FROM ponds WHERE pond_id = ?', [id]);
  return result.affectedRows > 0;
};
exports.getPondsByUserId = async (user_id) => {
  const [rows] = await db.query('SELECT * FROM ponds WHERE user_id = ?', [user_id]);
  return rows;
};