const measurementModel = require('../models/measurementModel');

exports.getAllMeasurements = async (req, res) => {
  try {
    const data = await measurementModel.getAllMeasurements();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMeasurementById = async (req, res) => {
  try {
    const m = await measurementModel.getMeasurementById(req.params.id);
    if (!m) return res.status(404).json({ error: 'Measurement not found' });
    res.json(m);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMeasurementsByPondId = async (req, res) => {
  try {
    const data = await measurementModel.getMeasurementsByPondId(req.params.pondId);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createMeasurement = async (req, res) => {
  try {
    const newData = await measurementModel.createMeasurement(req.body);
    res.status(201).json(newData);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteMeasurement = async (req, res) => {
  try {
    const success = await measurementModel.deleteMeasurement(req.params.id);
    if (!success) return res.status(404).json({ error: 'Measurement not found' });
    res.json({ message: 'Measurement deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};