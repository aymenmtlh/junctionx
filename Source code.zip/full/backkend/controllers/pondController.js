const pondModel = require('../models/pondModel');

exports.getAllPonds = async (req, res) => {
  try {
    const ponds = await pondModel.getAllPonds();
    res.json(ponds);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getPondById = async (req, res) => {
  try {
    const pond = await pondModel.getPondById(req.params.id);
    if (!pond) return res.status(404).json({ error: 'Pond not found' });
    res.json(pond);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createPond = async (req, res) => {
  const { name, location, user_id } = req.body;
  try {
    const newPond = await pondModel.createPond(name, location, user_id);
    res.status(201).json(newPond);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updatePond = async (req, res) => {
  const { name, location } = req.body;
  try {
    const success = await pondModel.updatePond(req.params.id, name, location);
    if (!success) return res.status(404).json({ error: 'Pond not found' });
    res.json({ message: 'Pond updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deletePond = async (req, res) => {
  try {
    const success = await pondModel.deletePond(req.params.id);
    if (!success) return res.status(404).json({ error: 'Pond not found' });
    res.json({ message: 'Pond deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
exports.getPondsByUserId = async (req, res) => {
  try {
    const ponds = await pondModel.getPondsByUserId(req.params.userId);
    res.json(ponds);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};