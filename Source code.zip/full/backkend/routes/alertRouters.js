const express = require('express');
const router = express.Router();
const alertController = require('../controllers/alertControllers');

/**
 * @swagger
 * tags:
 *   name: Alerts
 *   description: Manage pond alerts
 */

/**
 * @swagger
 * /alerts:
 *   get:
 *     summary: Get all alerts
 *     tags: [Alerts]
 *     responses:
 *       200:
 *         description: List of alerts
 */
router.get('/', alertController.getAllAlerts);

/**
 * @swagger
 * /alerts/{id}:
 *   get:
 *     summary: Get an alert by ID
 *     tags: [Alerts]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *     responses:
 *       200:
 *         description: Alert details
 */
router.get('/:id', alertController.getAlertById);

/**
 * @swagger
 * /alerts/pond/{pondId}:
 *   get:
 *     summary: Get alerts for a specific pond
 *     tags: [Alerts]
 *     parameters:
 *       - name: pondId
 *         in: path
 *         required: true
 *     responses:
 *       200:
 *         description: Alerts for a given pond
 */
router.get('/pond/:pondId', alertController.getAlertsByPondId);

module.exports = router;