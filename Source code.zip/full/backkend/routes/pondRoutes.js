const express = require("express");
const router = express.Router();
const pondController = require("../controllers/pondController");

/**
 * @swagger
 * tags:
 *   name: Ponds
 *   description: Pond management
 */

/**
 * @swagger
 * /ponds:
 *   get:
 *     summary: Get all ponds
 *     tags: [Ponds]
 *     responses:
 *       200:
 *         description: List of ponds
 */
router.get("/", pondController.getAllPonds);

/**
 * @swagger
 * /ponds/{id}:
 *   get:
 *     summary: Get a pond by ID
 *     tags: [Ponds]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: Pond ID
 *     responses:
 *       200:
 *         description: Pond details
 */
router.get("/:id", pondController.getPondById);

/**
 * @swagger
 * /ponds/user/{userId}:
 *   get:
 *     summary: Get ponds assigned to a user
 *     tags: [Ponds]
 *     parameters:
 *       - name: userId
 *         in: path
 *         required: true
 *         description: User ID
 *     responses:
 *       200:
 *         description: List of user's ponds
 */
router.get("/user/:userId", pondController.getPondsByUserId);

/**
 * @swagger
 * /ponds:
 *   post:
 *     summary: Create a new pond
 *     tags: [Ponds]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, user_id]
 *             properties:
 *               name:
 *                 type: string
 *               user_id:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Pond created
 */
router.post("/", pondController.createPond);

/**
 * @swagger
 * /ponds/{id}:
 *   put:
 *     summary: Update a pond
 *     tags: [Ponds]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: Pond ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               user_id:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Pond updated
 */
router.put("/:id", pondController.updatePond);

/**
 * @swagger
 * /ponds/{id}:
 *   delete:
 *     summary: Delete a pond
 *     tags: [Ponds]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *     responses:
 *       200:
 *         description: Pond deleted
 */
router.delete("/:id", pondController.deletePond);

module.exports = router;