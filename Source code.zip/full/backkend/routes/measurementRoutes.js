const express = require('express');
const router = express.Router();
const controller = require('../controllers/measuremntControllers');

/**
 * @swagger
 * tags:
 *   name: Measurements
 *   description: Manage measurement records
 */

/**
 * @swagger
 * /measurements:
 *   get:
 *     summary: Get all measurements
 *     tags: [Measurements]
 *     responses:
 *       200:
 *         description: List of all measurements
 */
router.get('/', controller.getAllMeasurements);

/**
 * @swagger
 * /measurements/{id}:
 *   get:
 *     summary: Get a measurement by ID
 *     tags: [Measurements]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: Measurement ID
 *     responses:
 *       200:
 *         description: Measurement details
 */
router.get('/:id', controller.getMeasurementById);

/**
 * @swagger
 * /measurements/pond/{pondId}:
 *   get:
 *     summary: Get measurements by pond ID
 *     tags: [Measurements]
 *     parameters:
 *       - name: pondId
 *         in: path
 *         required: true
 *         description: Pond ID
 *     responses:
 *       200:
 *         description: List of measurements for a pond
 */
router.get('/pond/:pondId', controller.getMeasurementsByPondId);

/**
 * @swagger
 * /measurements:
 *   post:
 *     summary: Create a new measurement
 *     tags: [Measurements]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               pond_id:
 *                 type: integer
 *               timestamp:
 *                 type: string
 *                 format: date-time
 *               temperature:
 *                 type: number
 *               ph:
 *                 type: number
 *               dissolved_oxygen:
 *                 type: number
 *               ammonia:
 *                 type: number
 *               water_level:
 *                 type: number
 *               salinity:
 *                 type: number
 *               nitrite:
 *                 type: number
 *               nitrate:
 *                 type: number
 *     responses:
 *       201:
 *         description: Measurement created
 */
router.post('/', controller.createMeasurement);

/**
 * @swagger
 * /measurements/{id}:
 *   delete:
 *     summary: Delete a measurement by ID
 *     tags: [Measurements]
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *     responses:
 *       200:
 *         description: Measurement deleted
 */
router.delete('/:id', controller.deleteMeasurement);

module.exports = router;